#include "display.h"
#include <iostream>
//implement this function
void cpe::customPrint(const std::string& s){
  //write your code here!
	std::cout<<s;
}

