//DO NOT MODIFY THIS FILE!!!!!

#ifndef WORDPROCESS_H
#define WORDPROCESS_H

#include <string>

namespace cpe {
  std::string getMostPairsWord(std::string words[300]);
}

#endif
